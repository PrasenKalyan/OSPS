
  <?php include("head.php"); ?>    
       <div class="row">
        <div class="col-6 col-sm-6 col-lg-6" align="center"><a href="disp_list4.php" title="Raise New Request"><img src="../img/quote-request.png" class="img-fluid"/></a>
        <br />  <b>Raise New Request</b>
        </div>
        <div class="col-6 col-sm-6 col-lg-6" align="center"><a href="disp_list5.php" title=" Approve Request"><img src="../img/approved.png" class="img-fluid"/></a>
          <br />  <b>Approve Request</b>
        </div>
      </div>
	  <div class="row">
        <div class="col-6 col-sm-6 col-lg-6"  align="center"><a href="disp_list.php" title="Dispatch From Warehouse"><img src="../img/dispatch.jpg" class="img-fluid" /></a><br />
        <b>Dispatch From Warehouse</b>
        </div>
        <div class="col-6 col-sm-6 col-lg-6" align="center"><a href="disp_list2.php" title="Add to Warehouse"><img src="../img/add_dispatch.jpg" class="img-fluid"/></a>
        <br />
        <b>Add To Warehouse</b>
        </div>
      </div>
    <div class="row">
        <div class="col-6 col-sm-6 col-lg-6" align="center"><a href="list.php" title="Stock Report"><img src="../img/stock.jpg" class="img-fluid"/></a>
          <br />  <b>Stock Report</b>
        </div>
        <div class="col-6 col-sm-6 col-lg-6" align="center"><a href="add_prd.php" title="Add New Product"><img src="../img/add_prd.jpg" class="img-fluid"/></a>
         <br />  <b>Add New Product</b>
        </div>
      </div>
     
      
      
       <div class="row">
        <div class="col-6 col-sm-6 col-lg-6" align="center"><a href="disp_list8.php" title="Return"><img src="product.png" class="img-fluid"/></a>
        <br />  <b>Return</b>
        </div>
        <div class="col-6 col-sm-6 col-lg-6" align="center">
      
        </div>
      </div>

    </div> <!-- /container -->
  </body>
</html>

