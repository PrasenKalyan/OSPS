<!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Toggle Sidebar</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button> -->
					
<?php
/*$row = mysqli_fetch_assoc($stmt);
$total_pages = ceil($row["total"] / $results_per_page); // calculate total pages with results

                    echo "<ul class='pagination'>";
                     if($pagenumber>1)
 {
echo "<li><a href='tsviewentries.php?page=".($pagenumber-1)."&state=".$statei."' class='button'>Previous -- </a></li>"; 
}
echo "<li><a>".$pagenumber." -- "."</></li>";

echo "<li><a href='tsviewentries.php?page=".($pagenumber+1)."&state=".$statei."' class='button'>NEXT</a></li>";
echo "</ul>";*/
?>
  <!--              </div>
            </nav>-->