<?php include("head.php"); ?>

<html lang="en">
  <head>

  <style>
	#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
	</style>
  </head>
  <body>
    
  <form method="post" action="" >

                   <div class="row">
                            <div class="col-12 col-sm-12 col-lg-12">
                               <div class="box box-info">
								<div class="box-header with-border">
								  <h3 class="box-title"> Manager Approval</h3>
								</div>
                               
               
								  
                <div style="overflow-x:auto;">
                                    <table id="customers" style="width:100%; border:1px solid;">
                                      <thead>
                                    <tr><th>S.no</th> 
                                      <th>Site Name</th>
                                      <th>Indus ID</th>
                                   <th> Date</th>
                                    <th>Uploaded By</th>
                                    
                                    </tr>
                                    </thead>
                                    <tbody>
                                      
    
                                    <?php




  $a="select * from productsentry where manager='allstates' group by uid,uploadby order by data desc";
$sq=mysqli_query($link,$a);
while($r=mysqli_fetch_array($sq)){
    ?>
    <tr>
    <td><?php echo $r['sno'];?></td>
    <td><?php echo $r['sitename'];?></td>
    <td><?php echo $r['indid'];?></td>
    <td><?php $d= $r['data']; echo date('d-m-Y', strtotime($d));?></td>
    <td><?php echo $r['uploadby'];?></td>
   
      </tr>
      <?php 
}
?>
      
</tbody>
</table>
</form>
</body>

</div>        



					</div>				
					 <!-- <tr><td><a href="dispatch.php">Back To Home Page</a></td></tr> -->
                                </form>
								</div>
                            </div>
                        </div>
                        <!-- PAGE CONTENT BEGINS -->

                        <!-- PAGE CONTENT ENDS -->
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.page-content -->
        </div>
    </div><!-- /.main-content -->

    <?php include('template/footer.php'); ?>

   
</div>
</body>
<?php
$qtno="managerapprove.pdf";
    $body=ob_get_clean();
$body=iconv("UTF-8","UTF-8//IGNORE",$body);

include('mpdf/mpdf.php');
$mpdf=new \mPDF('c','A4','','',10,10,10,10,0,0);
$mpdf->writeHTML($body);
$mpdf->Output($qtno,'F');
?>
</body>
</html>
<?php 

?>